import { Component, OnInit } from '@angular/core';
import { DishService } from '../../service/dish.service';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {

	dish: any;
	constructor(private dishSer: DishService) { 
		this.getDish();
	}

	ngOnInit(): void {
	}
	
	getDish(){
		this.dishSer.getFav().subscribe((data:any)=>{
			this.dish = data;
			console.log(data);
		});
	}

}
