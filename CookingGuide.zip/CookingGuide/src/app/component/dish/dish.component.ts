import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { DishService } from '../../service/dish.service';

@Component({
  selector: 'app-dish',
  templateUrl: './dish.component.html',
  styleUrls: ['./dish.component.css']
})
export class DishComponent implements OnInit {

	dish:any;
	display: boolean = false;
	imageUrl: string = '';
	
	constructor(private route: ActivatedRoute, private dishSer: DishService) { 
		this.getDish(this.route.snapshot.params.id);
	}

	ngOnInit(): void {
		
	}
	
	getDish(id: any){
		this.dishSer.getDishById(id).subscribe((data:any)=>{
			this.dish = data;
			//this.imageUrl = this.dish.url;
			if(this.dish.view === 4 ){
				this.addToFav();
			}
			this.updateDish();
			console.log(data);
		});
	}
	
	updateDish(){
		this.dish.view += 1; 
		this.dishSer.updateDish(this.dish).subscribe((data:any)=>{
			this.dish = data;
		});
	}
	
	addToFav(){
		
		this.display = true;
		this.dishSer.createFav(this.dish).subscribe((data:any)=>{
			this.dish = data;
			console.log(data);
		});
	}
	
	close(){
		this.display = false;
	}
	
}
