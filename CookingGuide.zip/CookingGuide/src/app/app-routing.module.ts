import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DishComponent } from './component/dish/dish.component';
import { FavouritesComponent } from './component/favourites/favourites.component';

const routes: Routes = [{
    path: 'dish/:id',
    component: DishComponent
	},{
    path: 'favourites',
    component: FavouritesComponent
  }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
