import { Component } from '@angular/core';
import { CookingregionsService } from './service/cookingregions.service';
import { DishtypeService } from './service/dishtype.service';
import { DishService } from './service/dish.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	
	title = 'cookingGuide';
	allRegions:any;
	allDishType:any;
	allDish:any;
	
	constructor(private cookingSer: CookingregionsService,private dishTypeSer: DishtypeService,
				private dishSer: DishService) {
		this.getAllRegions();
		//this.getAllDishType();
		//this.getAllDish();
	}
	
	getAllRegions(){
		this.cookingSer.getAllRegions().subscribe((data:any)=>{
			this.allRegions = data;
			
			console.log(data);
		});
	}
	
	getAllDishType(){
		this.dishTypeSer.getAllDishType().subscribe((data:any)=>{
			this.allDishType = data;
			console.log(data);
		});
	}
	
	getAllDish(){
		this.dishSer.getAllDish().subscribe((data:any)=>{
			this.allDish = data;
			console.log(data);
		});
	}
	
}
