import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CookingregionsService {

	url = 'http://localhost:3000/regions';
	
	constructor(private http: HttpClient) { }
	
	
	getAllRegions(){
		return this.http.get(this.url);
	}
	
}
