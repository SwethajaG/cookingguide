import { TestBed } from '@angular/core/testing';

import { DishtypeService } from './dishtype.service';

describe('DishtypeService', () => {
  let service: DishtypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DishtypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
