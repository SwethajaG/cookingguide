import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DishService {

	url = 'http://localhost:3000/dish';
	favUrl = 'http://localhost:3000/favourites';
	
	constructor(private http: HttpClient) { }
	
	
	getAllDish(){
		return this.http.get(this.url);
	}
	
	getDishById(id: any){
		return this.http.get(this.url + '/' + id);
	}
	
	updateDish(dish: any){
		
		return this.http.put(this.url + '/' + dish.id , dish);
	}
	
	createFav(fav: any){
		return this.http.post(this.favUrl , fav);
	}
	
	getFav(){
		return this.http.get(this.favUrl);
	}
	
}
