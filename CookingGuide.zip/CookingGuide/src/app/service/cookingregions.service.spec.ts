import { TestBed } from '@angular/core/testing';

import { CookingregionsService } from './cookingregions.service';

describe('CookingregionsService', () => {
  let service: CookingregionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CookingregionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
